# -*- coding: utf-8 -*-

import os

DATA='E:\SUNJINGJING\Strategy\DATA'
WIND_A= os.path.join(DATA,'881001.csv')
FACTORS_DETAIL_PATH=os.path.join(DATA,'quant_dict_factors_all.csv')

ORIGIN='E:/SUNJINGJING/Strategy/ALpha/data/origin'
ANALYSIS='E:/SUNJINGJING/Strategy/ALpha/data/analysis'

# notebook
# DATA='D:\strategy\DATA'
