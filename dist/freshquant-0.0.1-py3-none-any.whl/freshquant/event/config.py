# -*- coding: utf-8 -*-

'''
7.1 公告:news.announcement
7.2 公告类型: dict_announce_catalog
7.3 公告正负面判断:ada.dict_announce_customtyp
7.4 新闻分析: news.subnews_analyse
7.5 每日热点新闻:news.topnews_anylyse
'''

import os

# pwd = os.path.dirname(os.path.abspath(__file__))
# TRADE_CAL_PATH = os.path.join(pwd, 'trade_cal.csv')
# FACTORS_DETAIL_PATH = os.path.join(pwd, 'quant_dict_factors_all.csv')
# END_TD_PATH = os.path.join(pwd, 'end_td.txt')
# EX_METHOD = 'mad'  #　标准化std, mad
# SCALE_METHOD = 'normal'  # normal, cap, sector

DEFALUT_HOST = '122.144.134.95'
PATH = 'E:\SUNJINGJING\Strategy\EVENT'
EVENT_DATA='E:\SUNJINGJING\Strategy\EVENT\事件库'