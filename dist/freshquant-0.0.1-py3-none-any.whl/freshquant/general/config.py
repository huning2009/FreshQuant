# -*- coding: UTF-8 -*-

DEFALUT_HOST = '192.168.250.200'
DEFALUT_HOST_COMPONETS = '192.168.250.200'   # 200 ada.index_members_a   历史成分股
TRADE_CAL_PATH = 'E:/SUNJINGJING/Strategy/utils_strategy/general/trade_cal.csv'